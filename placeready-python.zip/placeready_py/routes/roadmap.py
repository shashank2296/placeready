from fastapi import APIRouter, Depends
from pydantic import BaseModel
from security import current_user
from services.ai import PERSONA, candidate, stream_reply

router = APIRouter(prefix="/api")


class RoadmapBody(BaseModel):
    role: str = ""
    weeks: int = 6


@router.post("/roadmap")
def roadmap(b: RoadmapBody, user=Depends(current_user)):
    weeks = max(2, min(16, b.weeks))
    msg = (f"Create a {weeks}-week placement preparation roadmap for my skill gaps and target role. "
           "Format: **Week N – focus**, then 2-3 bullets with concrete tasks and free resources. End with one milestone.")
    return stream_reply(PERSONA + candidate(user, b.role) + "\nYou may write up to 350 words for roadmaps.", [{"role": "user", "content": msg}])
