import re
from typing import List
from fastapi import APIRouter, Depends
from pydantic import BaseModel
import database as db
from security import current_user
from services.ai import PERSONA, candidate, clean_messages, stream_reply

router = APIRouter(prefix="/api")

INTERVIEW = ('\nYou are running a MOCK INTERVIEW. When the candidate answers: give brief feedback (good, improve, '
             'one-line model answer), then a line exactly like "SCORE: 7/10", then ask the NEXT single question. '
             'Ask only one question at a time. If they ask for a hint, give a small hint without the answer.')


class Msg(BaseModel):
    role: str
    content: str


class InterviewBody(BaseModel):
    messages: List[Msg]
    role: str = ""


@router.post("/interview")
def interview(b: InterviewBody, user=Depends(current_user)):
    msgs = [m.model_dump() for m in b.messages]
    last_q = next((m["content"] for m in reversed(msgs) if m["role"] == "assistant"), "")

    def save_score(full: str):
        m = re.search(r"SCORE:\s*(\d+(?:\.\d+)?)\s*/\s*10", full, re.I)
        if m:
            db.run("insert into interviews(user_id,question,score) values(?,?,?)", (user["id"], last_q[:300], min(10.0, float(m.group(1)))))

    return stream_reply(PERSONA + candidate(user, b.role) + INTERVIEW, clean_messages(msgs), on_done=save_score)


@router.get("/progress")
def progress(user=Depends(current_user)):
    rs = db.query("select ats, created from resumes where user_id=? order by id", (user["id"],))
    iv = db.query("select score, created from interviews where user_id=? order by id", (user["id"],))
    return {"resumes": [dict(r) for r in rs], "interviews": [dict(i) for i in iv]}
