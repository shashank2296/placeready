import json
from typing import Optional
from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile
from pydantic import BaseModel
import database as db
from security import current_user
from services.parser import extract_text
from services.ats import analyze, gaps
from services.ai import PERSONA, candidate, stream_reply

router = APIRouter(prefix="/api")


@router.post("/resume")
async def upload(role: str = Form(""), text: str = Form(""), file: Optional[UploadFile] = File(None), user=Depends(current_user)):
    """Upload a file or paste text; returns the ATS analysis."""
    if file is not None:
        text = extract_text(file.filename or "", await file.read())
    if len(text.strip()) < 80:
        raise HTTPException(400, "Could not read enough text from the resume")
    a = analyze(text)
    db.run("insert into resumes(user_id,text,ats,skills) values(?,?,?,?)", (user["id"], text, a["ats"], json.dumps(a["skills"])))
    return {**a, "gaps": gaps(role, a["skills"])}


class RoleBody(BaseModel):
    role: str = ""


@router.post("/resume/feedback")
def feedback(b: RoleBody, user=Depends(current_user)):
    msg = ("Give personalised feedback on my resume for my target role: 2 strengths, the 3 most valuable "
           "improvements (rewrite one weak bullet as an example), then the next step.")
    return stream_reply(PERSONA + candidate(user, b.role), [{"role": "user", "content": msg}])
