import re
import sqlite3
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
import database as db
import security

router = APIRouter(prefix="/api")


class Creds(BaseModel):
    email: str
    password: str
    name: str = ""


@router.post("/register")
def register(c: Creds):
    if not re.match(r"^\S+@\S+\.\S+$", c.email) or not c.name or len(c.password) < 6:
        raise HTTPException(400, "Enter a name, valid email and a password of 6+ characters")
    try:
        uid = db.run("insert into users(email,name,hash) values(?,?,?)", (c.email.lower(), c.name, security.hash_pw(c.password)))
    except sqlite3.IntegrityError:
        raise HTTPException(409, "That email is already registered")
    return {"token": security.make_token(uid, c.name), "name": c.name}


@router.post("/login")
def login(c: Creds):
    u = db.query("select * from users where email=?", (c.email.lower(),), one=True)
    if not u or not security.check_pw(c.password, u["hash"]):
        raise HTTPException(401, "Wrong email or password")
    return {"token": security.make_token(u["id"], u["name"]), "name": u["name"]}
