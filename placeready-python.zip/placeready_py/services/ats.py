"""Rule-based ATS scoring. Edit SKILLS / ROLE_SKILLS / the checks to fit your needs."""
import re

SKILLS = ["python", "java", "javascript", "typescript", "c++", "c#", "go", "kotlin", "php", "sql", "html", "css", "react", "angular", "vue", "node.js", "express", "django", "flask", "fastapi", "spring boot", "rest", "graphql", "pandas", "numpy", "scikit-learn", "tensorflow", "pytorch", "machine learning", "deep learning", "nlp", "data analysis", "tableau", "power bi", "excel", "statistics", "aws", "azure", "docker", "kubernetes", "git", "github", "linux", "ci/cd", "mongodb", "mysql", "postgresql", "firebase", "data structures", "algorithms", "oop", "operating systems", "dbms", "computer networks", "system design", "agile", "unit testing", "microservices", "leadership", "communication", "teamwork", "problem solving"]
ROLE_SKILLS = {
    "data": ["python", "sql", "pandas", "statistics", "tableau", "machine learning"],
    "web": ["javascript", "react", "node.js", "html", "css", "git", "rest"],
    "software": ["data structures", "algorithms", "oop", "system design", "git", "sql", "dbms"],
    "other": ["git", "sql", "communication", "problem solving"],
}
VERBS = ["built", "developed", "designed", "implemented", "led", "created", "optimized", "improved", "reduced", "increased", "automated", "deployed", "launched", "analyzed", "integrated", "delivered"]
SECTIONS = {"education": r"education", "experience": r"experience|internship", "projects": r"project", "skills": r"skills", "summary": r"summary|objective|profile", "achievements": r"achievement|certif|award"}


def has(text: str, word: str) -> bool:
    return re.search(r"(^|[^a-z0-9+#.])" + re.escape(word) + r"(?![a-z0-9+#])", text, re.I) is not None


def gaps(role: str, skills: list) -> list:
    r = (role or "").lower()
    key = "data" if "data" in r else "web" if re.search(r"web|front|full", r) else "software" if re.search(r"soft|develop|engineer", r) else "other"
    return [s for s in ROLE_SKILLS[key] if s not in skills]


def analyze(text: str) -> dict:
    t = text.lower()
    lines = [l.strip() for l in text.splitlines() if l.strip()]
    sections = [k for k, p in SECTIONS.items() if any(len(l) < 40 and re.search(p, l.lower()) for l in lines)]
    skills = [s for s in SKILLS if has(t, s)]
    verbs = [v for v in VERBS if has(t, v)]
    metrics = len(re.findall(r"\b\d+(\.\d+)?\s?(%|x|\+|k\b|users|ms)", text, re.I))
    words = len(text.split())
    ats, tips = 0, []

    def check(points, ok, tip):
        nonlocal ats
        if ok:
            ats += points
        else:
            tips.append(tip)

    check(10, re.search(r"[\w.+-]+@[\w-]+\.\w+", text) and len(re.sub(r"\D", "", text)) >= 8, "Add a professional email and phone number")
    check(5, re.search(r"linkedin|github", text, re.I), "Add LinkedIn and GitHub links")
    check(20, len(sections) >= 4, f"Use clear section headings (found {len(sections)} of 6)")
    check(15, len(skills) >= 8, f"List at least 8 relevant skills (found {len(skills)})")
    check(15, len(verbs) >= 5, "Start bullets with action verbs like Built, Optimized, Led")
    check(15, metrics >= 3, 'Quantify impact with numbers, e.g. "cut load time by 40%"')
    check(10, 250 <= words <= 900, f"Resume is short ({words} words): expand projects" if words < 250 else "Resume is long: trim to 1-2 pages")
    return {"ats": ats, "skills": skills, "tips": tips, "sections": sections}
