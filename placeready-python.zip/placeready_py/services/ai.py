import json
import anthropic
from fastapi.responses import StreamingResponse
import config
import database as db

client = anthropic.Anthropic()  # reads ANTHROPIC_API_KEY from the environment

PERSONA = ('You are Aria, a warm, concise placement coach for students and freshers. Be encouraging, '
           'specific and practical. Use short paragraphs and "-" bullets. Never invent resume facts. '
           'Keep replies under 180 words unless asked.')


def candidate(user: dict, role: str) -> str:
    """Describes the candidate (latest resume + role) for the system prompt."""
    r = db.query("select * from resumes where user_id=? order by id desc limit 1", (user["id"],), one=True)
    s = f"\nCandidate: {user['name']}. Target role: {role or 'unknown'}."
    if r:
        s += f"\nATS score: {r['ats']}. Skills: {', '.join(json.loads(r['skills']))}.\nResume:\n{r['text'][:4000]}"
    else:
        s += "\nNo resume uploaded yet."
    return s


def clean_messages(messages: list) -> list:
    m = [{"role": x["role"], "content": x["content"]} for x in messages[-12:]]
    while m and m[0]["role"] != "user":  # the API needs the first message to be from the user
        m.pop(0)
    return m


def stream_reply(system: str, messages: list, on_done=None) -> StreamingResponse:
    """Streams Claude's reply to the browser as plain text."""
    def gen():
        full = ""
        try:
            with client.messages.stream(model=config.MODEL, max_tokens=900, system=system, messages=messages) as s:
                for t in s.text_stream:
                    full += t
                    yield t
        except Exception as e:
            yield f"\n[AI error: {e}]"
        if on_done:
            on_done(full)
    return StreamingResponse(gen(), media_type="text/plain; charset=utf-8")
