import io
from pypdf import PdfReader
from docx import Document


def extract_text(filename: str, data: bytes) -> str:
    """Turns an uploaded PDF / DOCX / TXT file into plain text."""
    n = filename.lower()
    if n.endswith(".pdf"):
        return "\n".join((p.extract_text() or "") for p in PdfReader(io.BytesIO(data)).pages)
    if n.endswith(".docx"):
        return "\n".join(p.text for p in Document(io.BytesIO(data)).paragraphs)
    return data.decode("utf-8", errors="ignore")
